function minhaFuncao() {
    total=8;

    for(var i=1;i<=total;i++){
        var str="";
        for(var j=1;j<=i;j++){
        str += j+" ";
        }
        console.log(str);
     }
    

}
